const categories=["Quiz","Long Quiz","Midterm","Final","Laboratory","Project"];
const defaultScores=[
 {id:1,category:"Quiz",name:"Quiz 1",score:18,max:20,date:""},
 {id:2,category:"Long Quiz",name:"Long Quiz 1",score:42,max:50,date:""},
 {id:3,category:"Midterm",name:"Midterm Exam",score:86,max:100,date:""},
 {id:4,category:"Laboratory",name:"Laboratory Activity 1",score:46,max:50,date:""},
 {id:5,category:"Project",name:"Final Project",score:92,max:100,date:""}
];
let scores=JSON.parse(localStorage.getItem("academicScores")||"null")||defaultScores;
let images=JSON.parse(localStorage.getItem("academicImages")||"[]");
let profile=JSON.parse(localStorage.getItem("academicProfile")||"{}");
let scoreFilter="All", galleryFilter="All";

const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
function save(){localStorage.setItem("academicScores",JSON.stringify(scores));localStorage.setItem("academicImages",JSON.stringify(images));}
function pct(x){return x.max?Math.round(x.score/x.max*100):0}
function avg(cat){const a=scores.filter(x=>x.category===cat);return a.length?Math.round(a.reduce((s,x)=>s+pct(x),0)/a.length):0}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function showSection(id){$$(".page-section").forEach(x=>x.classList.remove("active-section"));$("#"+id).classList.add("active-section");$$(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.target===id))}
$$(".nav-item").forEach(b=>b.onclick=()=>showSection(b.dataset.target));
$$("[data-jump]").forEach(b=>b.onclick=()=>showSection(b.dataset.jump));

function renderOverview(){
  const vals=categories.map(avg), overall=vals.filter(Boolean).length?Math.round(vals.filter(Boolean).reduce((a,b)=>a+b,0)/vals.filter(Boolean).length):0;
  $("#overallGrade").textContent=overall+"%";
  ["quizStat","longQuizStat","midtermStat","finalStat","labStat","projectStat"].forEach((id,i)=>$("#"+id).textContent=vals[i]+"%");
  $("#scoreBars").innerHTML=categories.map((c,i)=>`<div class="bar-row"><span>${c}</span><div class="bar"><i style="width:${vals[i]}%"></i></div><strong>${vals[i]}%</strong></div>`).join("");
  const recent=[...scores].slice(-5).reverse();
  $("#recentRecords").innerHTML=recent.length?recent.map(x=>`<div class="record"><div><strong>${x.name}</strong><small>${x.category}${x.date?" • "+x.date:""}</small></div><span class="score">${x.score}/${x.max}</span></div>`).join(""):`<div class="empty">No records yet.</div>`;
}
function renderScores(){
  const list=scoreFilter==="All"?scores:scores.filter(x=>x.category===scoreFilter);
  $("#scoreTableWrap").innerHTML=list.length?`<table class="table"><thead><tr><th>Assessment</th><th>Category</th><th>Date</th><th>Score</th><th>Percent</th><th></th></tr></thead><tbody>${list.map(x=>`<tr><td><strong>${x.name}</strong></td><td>${x.category}</td><td>${x.date||"—"}</td><td>${x.score}/${x.max}</td><td class="score-percent">${pct(x)}%</td><td><button class="delete" onclick="deleteScore(${x.id})">Delete</button></td></tr>`).join("")}</tbody></table>`:`<div class="empty">No scores in this category.</div>`;
}
function renderGallery(){
  const list=galleryFilter==="All"?images:images.filter(x=>x.category===galleryFilter);
  $("#galleryGrid").innerHTML=list.length?list.map(x=>`<article class="gallery-item"><img src="${x.data}" alt="${x.name}"><div class="gallery-info"><button class="remove-img" onclick="deleteImage('${x.id}')">×</button><strong>${x.name}</strong><small>${x.category}</small></div></article>`).join(""):`<div class="empty" style="grid-column:1/-1">No pictures uploaded for this category.</div>`;
}
function render(){renderOverview();renderScores();renderGallery();loadProfile()}
function openModal(){ $("#scoreModal").classList.add("open");$("#scoreDate").value=new Date().toISOString().slice(0,10)}
function closeModal(){ $("#scoreModal").classList.remove("open")}
$("#addScoreBtn").onclick=openModal;$("#addScoreBtn2").onclick=openModal;$$("[data-close]").forEach(b=>b.onclick=closeModal);
$("#scoreModal").onclick=e=>{if(e.target.id==="scoreModal")closeModal()};
$("#scoreForm").onsubmit=e=>{e.preventDefault();scores.push({id:Date.now(),category:$("#scoreCategory").value,name:$("#assessmentName").value.trim(),score:Number($("#scoreValue").value),max:Number($("#maxScore").value),date:$("#scoreDate").value});save();render();closeModal();e.target.reset();toast("Score added successfully.");showSection("scores")};
window.deleteScore=id=>{scores=scores.filter(x=>x.id!==id);save();render();toast("Score deleted.")};
$$(".filter").forEach(b=>{b.onclick=()=>{scoreFilter=b.dataset.filter;$$(".filter").forEach(x=>x.classList.toggle("active",x.dataset.filter===scoreFilter));renderScores()}});
$("#browseBtn").onclick=()=>$("#imageInput").click();
$("#galleryCategory").onchange=()=>{};
$("#imageInput").onchange=e=>handleFiles([...e.target.files]);
$("#dropZone").onclick=e=>{if(!e.target.closest("button"))$("#imageInput").click()};
["dragenter","dragover"].forEach(ev=>$("#dropZone").addEventListener(ev,e=>{e.preventDefault();$("#dropZone").classList.add("drag")}));
["dragleave","drop"].forEach(ev=>$("#dropZone").addEventListener(ev,e=>{e.preventDefault();$("#dropZone").classList.remove("drag")}));
$("#dropZone").addEventListener("drop",e=>handleFiles([...e.dataTransfer.files]));
async function handleFiles(files){
  const cat=$("#galleryCategory").value;
  const imgs=files.filter(f=>f.type.startsWith("image/"));
  for(const f of imgs){
    const data=await fileToDataURL(f);
    images.push({id:crypto.randomUUID?crypto.randomUUID():Date.now()+Math.random(),name:f.name,data,category:cat});
  }
  save();renderGallery();toast(`${imgs.length} picture${imgs.length!==1?"s":""} uploaded to ${cat}.`);
}
function fileToDataURL(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)})}
$$("[data-gallery-filter]").forEach(b=>b.onclick=()=>{galleryFilter=b.dataset.galleryFilter;$$("[data-gallery-filter]").forEach(x=>x.classList.toggle("active",x.dataset.galleryFilter===galleryFilter));renderGallery()});
window.deleteImage=id=>{images=images.filter(x=>x.id!==id);save();renderGallery();toast("Picture removed.")};
function loadProfile(){if(profile.name)$("#studentName").value=profile.name;if(profile.course)$("#studentCourse").value=profile.course;if(profile.school)$("#studentSchool").value=profile.school;if(profile.goal)$("#studentGoal").value=profile.goal}
$("#saveProfile").onclick=()=>{profile={name:$("#studentName").value,course:$("#studentCourse").value,school:$("#studentSchool").value,goal:$("#studentGoal").value};localStorage.setItem("academicProfile",JSON.stringify(profile));toast("Profile saved.")};
$("#resetData").onclick=()=>{if(confirm("Reset all scores, pictures, and profile data?")){localStorage.clear();location.reload()}};
render();
